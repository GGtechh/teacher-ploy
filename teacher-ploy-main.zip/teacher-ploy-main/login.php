<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://kit.fontawesome.com/0949ce2d03.js" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/logotest.png">
    <title>TEACHER PLOY</title>
    <link rel="stylesheet" href="assets/js/fullcalendar/lib/main.css">
    <script src="assets/js/fullcalendar/lib/main.js"></script>
</head>
<body>
<i class="fa-solid fa-user"></i> -->
    <!-- <a href="3fb8fb4e7f46f6f3729d0d7ab6b7a54ba41014df">student</a> -->
    <!-- <i class="fa-light fa-head-side-cough"></i><i class="fa-light fa-ear-listen"></i>
    <i class="fa-light fa-people-arrows"></i><i class="fa-light fa-book"></i>
    <label for="">เข้าสู่ระบบ</label>
    <form action="src/src/login.php" method="post">
        <input type="text" name="user" id="" value="" required> 
        <input type="password" name="password" id="" required>
        <input type="submit" value="submit">
    </form>
    <label for="">สมัครสมาชิก</label>
    <form action="src/src/register.php" method="post">
        <input type="text" name="user" id="" value="" placeholder="user" required> <br>
        <input type="password" name="password" id="" placeholder="password" required><br>
        <input type="text" name="tel" id="" value="" placeholder="tel" required> <br>
        <input type="text" name="etp" id="" value="" placeholder="etp" required> <br>
        <input type="text" name="fname_s" id="" value="" placeholder="fname_s" required> <br>
        <input type="text" name="lname_s" id="" value="" placeholder="lname_s" required> <br>
        <input type="text" name="fname_ep" id="" value="" placeholder="fname_ep" required> <br>
        <input type="text" name="lname_ep" id="" value="" placeholder="lname_ep" required><br>
        <input type="text" name="address" id="" value="" placeholder="address" required> <br>
        <input type="text" name="status" id="" value="" placeholder="status" required> <br>
        <input type="text" name="school" id="" value="" placeholder="school" required> <br>
        <input type="submit" value="submit">
    </form>
    
</body>
</html> -->
 

<!DOCTYPE html>
<!-- === Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/logotest.png">
    <title>TEACHER PLOY</title>
    <!-- ===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="assets/css/login.CSS">
         
    <!--<title>Login & Registration Form</title>-->
</head>
<body>
    
    <div class="container">
        <div class="forms">
            <div class="form login">
                <span class="title">เข้าสู่ระบบ</span>

                <form action="src/src/login.php" method="post">
                    <div class="input-field">
                        <input type="text" name="user" placeholder="ชื่อผู้ใช้งาน" id="" value="" required> 
                        <i class="uil uil-envelope icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" name="password" class="password" placeholder="รหัสผ่าน" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>

                    <div class="checkbox-text">
                        <!-- <div class="checkbox-content">
                            <input type="checkbox" id="logCheck">
                            <label for="logCheck" class="text">Remember me</label>
                        </div> -->
                        
                        <!-- <a href="#" class="text">Forgot password?</a> -->
                    </div>

                    <div class="input-field button">
                        <input type="submit" name="submit" value="เข้าสู่ระบบ">
                    </div>
                </form>

                <div class="login-signup">
                    <span class="text">ยังไม่มีสมาชิก
                        <a href="register.php" class="text signup-link">สมัครตอนนี้</a>
                    </span>
                </div>
            </div>

            <!-- Registration Form -->
            <!-- <div class="form signup">
                <span class="title">สมัครสมาชิก</span>

                <form action="#">
                    <div class="input-field">
                        <input type="text" placeholder="Enter your name" required>
                        <i class="uil uil-user"></i>
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="Enter your email" required>
                        <i class="uil uil-envelope icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" class="password" placeholder="Create a password" required>
                        <i class="uil uil-lock icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" class="password" placeholder="Confirm a password" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>

                    <div class="checkbox-text">
                        <div class="checkbox-content">
                            <input type="checkbox" id="termCon">
                            <label for="termCon" class="text">I accepted all terms and conditions</label>
                        </div>
                    </div>

                    <div class="input-field button">
                        <input type="button" value="Signup">
                    </div>
                </form>

                <div class="login-signup">
                    <span class="text">Already a member?
                        <a href="#" class="text login-link">Login Now</a>
                    </span>
                </div>
            </div> -->
        </div>
    </div>

    <!--<script src="script.js"></script>-->
</body>
</html>

<script>
    const container = document.querySelector(".container"),
      pwShowHide = document.querySelectorAll(".showHidePw"),
      pwFields = document.querySelectorAll(".password"),
      signUp = document.querySelector(".signup-link"),
      login = document.querySelector(".login-link");

    //   js code to show/hide password and change icon
    pwShowHide.forEach(eyeIcon =>{
        eyeIcon.addEventListener("click", ()=>{
            pwFields.forEach(pwField =>{
                if(pwField.type ==="password"){
                    pwField.type = "text";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye-slash", "uil-eye");
                    })
                }else{
                    pwField.type = "password";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye", "uil-eye-slash");
                    })
                }
            }) 
        })
    })

    // js code to appear signup and login form
    // signUp.addEventListener("click", ( )=>{
    //     container.classList.add("active");
    // });
    login.addEventListener("click", ( )=>{
        container.classList.remove("active");
    });

</script>