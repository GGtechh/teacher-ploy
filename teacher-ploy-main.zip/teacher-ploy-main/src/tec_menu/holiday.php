<h2>เพิ่มวันหยุด</h2>
                <div class="updates">
                    <form action="" method="post" class="form">
                        <div class="input-data">
                            <input type="date" required>
                            <div class="underline"></div>
                            <!-- <label>Name</label> -->
                        </div>
                        <div class="submis">
                            <button type="submit" class="submi">ยืนยัน</button>
                        </div>
                        
                    </form>
                </div>