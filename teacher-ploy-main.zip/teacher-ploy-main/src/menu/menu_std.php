<aside>
            <div class="top">
                <div class="logo">
                    <!-- <img src="assets/img/logotest.png" alt=""> -->
                    <h2>TEACHER<span class="danger">PLOY</span></h2>
                </div>
                <div class="close" id="close-btn">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <div class="sidebar">
                <a href="student.php?page=timetable_std">
                    <i class="fa-solid fa-graduation-cap"></i>
                    <h3>คอร์สเรียน</h3>
                </a>
                <a href="student.php?page=payment_std">
                    <i class="fa-solid fa-border-all"></i>
                    <h3>สถานะการจ่ายเงิน</h3>
                </a>
                <a href="student.php?page=homework_std">
                    <i class="fa-solid fa-book-open"></i>
                    <h3>แบบทดสอบ</h3>
                </a>
                <a href="student.php?page=news_std">
                    <i class="fa-solid fa fa-newspaper-o"></i>
                    <h3>ข่าวสาร</h3>
                </a>
                
                <a href="student.php?logout='1'">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <h3>ออกจากระบบ</h3>
                </a>
            </div>
        </aside>